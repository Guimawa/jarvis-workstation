import React from 'react';

const Timeline: React.FC = () => {
  return (
    <div className="card p-3 w-full">
      <div className="text-sm text-white/60">Timeline (vide)</div>
      <div className="mt-2 h-10 bg-white/5 rounded-md border border-white/10" />
    </div>
  );
};

export default Timeline;
