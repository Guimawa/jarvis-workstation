import React from 'react';

const GraphPlaceholder: React.FC = () => {
  return (
    <div className="card h-full w-full flex items-center justify-center">
      <div className="text-white/60 text-sm">
        Graph réseau (placeholder) — prêt pour react-force-graph
      </div>
    </div>
  );
};

export default GraphPlaceholder;
