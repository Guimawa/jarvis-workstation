import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="card px-4 py-3 flex items-center gap-3">
      <input
        className="flex-1 bg-transparent outline-none placeholder-white/40"
        placeholder="Search…"
      />
      <div className="flex gap-2">
        <button className="px-3 py-1 bg-white/5 rounded-lg border border-white/10">Statut</button>
        <button className="px-3 py-1 bg-white/5 rounded-lg border border-white/10">Date</button>
        <button className="px-3 py-1 bg-white/5 rounded-lg border border-white/10">Outil</button>
      </div>
    </header>
  );
};

export default Header;
