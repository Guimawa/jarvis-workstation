import React from 'react';

const RankingPanel: React.FC = () => {
  return (
    <aside className="card h-full p-4 w-full">
      <div className="text-sm text-white/60 mb-3">Ranking (vide)</div>
      <div className="space-y-2">
        {Array.from({length: 6}).map((_, i) => (
          <div key={i} className="h-8 bg-white/5 rounded-md border border-white/10" />
        ))}
      </div>
    </aside>
  );
};

export default RankingPanel;
