import React, { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import ForceGraph2D from 'react-force-graph-2d';
import { Search, Filter, TrendingUp, Users, MessageSquare, Calendar, BarChart3, Activity } from 'lucide-react';

// Données mockées
const stats = [
  { label: 'Projets actifs', value: '24', change: '+12%', icon: TrendingUp },
  { label: 'Participants', value: '1.2K', change: '+8%', icon: Users },
  { label: 'Messages', value: '3.4K', change: '+15%', icon: MessageSquare },
  { label: 'Événements', value: '18', change: '+5%', icon: Calendar },
];

const lineSeries = [
  { name: 'Jan', projets: 12, participants: 800, messages: 1200 },
  { name: 'Fév', projets: 15, participants: 950, messages: 1500 },
  { name: 'Mar', projets: 18, participants: 1100, messages: 1800 },
  { name: 'Avr', projets: 22, participants: 1200, messages: 2200 },
  { name: 'Mai', projets: 24, participants: 1200, messages: 3400 },
];

const topics = [
  { id: 'ai', name: 'Intelligence Artificielle', count: 45, color: '#22d3ee' },
  { id: 'blockchain', name: 'Blockchain', count: 32, color: '#a78bfa' },
  { id: 'web3', name: 'Web3', count: 28, color: '#fbbf24' },
  { id: 'defi', name: 'DeFi', count: 24, color: '#34d399' },
  { id: 'nft', name: 'NFT', count: 19, color: '#f87171' },
];

const ranking = [
  { rank: 1, name: 'Alice Martin', score: 98, projects: 12, avatar: 'AM' },
  { rank: 2, name: 'Bob Dupont', score: 95, projects: 10, avatar: 'BD' },
  { rank: 3, name: 'Claire Moreau', score: 92, projects: 9, avatar: 'CM' },
  { rank: 4, name: 'David Leroy', score: 89, projects: 8, avatar: 'DL' },
  { rank: 5, name: 'Emma Bernard', score: 87, projects: 7, avatar: 'EB' },
];

// Fonction pour construire le réseau
const buildNetwork = () => {
  const nodes = [
    { id: 'hub1', name: 'Hub Principal', type: 'hub', size: 20, color: '#22d3ee' },
    { id: 'event1', name: 'Conf IA 2024', type: 'event', size: 15, color: '#a78bfa' },
    { id: 'influencer1', name: 'Tech Leader', type: 'influencer', size: 12, color: '#fbbf24' },
    { id: 'project1', name: 'Projet Alpha', type: 'project', size: 10, color: '#34d399' },
    { id: 'project2', name: 'Projet Beta', type: 'project', size: 10, color: '#f87171' },
    { id: 'event2', name: 'Meetup Web3', type: 'event', size: 15, color: '#a78bfa' },
  ];

  const links = [
    { source: 'hub1', target: 'event1', strength: 0.8 },
    { source: 'hub1', target: 'influencer1', strength: 0.9 },
    { source: 'hub1', target: 'project1', strength: 0.7 },
    { source: 'hub1', target: 'project2', strength: 0.6 },
    { source: 'event1', target: 'influencer1', strength: 0.5 },
    { source: 'event2', target: 'project1', strength: 0.4 },
  ];

  return { nodes, links };
};

const HandshakeDashboardTemplate: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const networkData = useMemo(() => buildNetwork(), []);

  const tabs = [
    { id: 'overview', name: 'Vue d\'ensemble', icon: BarChart3 },
    { id: 'network', name: 'Réseau', icon: Activity },
    { id: 'analytics', name: 'Analytics', icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-bg text-ink">
      {/* Header */}
      <header className="border-b border-white/10 bg-panel/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-accent-1 to-accent-3 bg-clip-text text-transparent">
                Handshake Dashboard
              </h1>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Rechercher..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent-1/50"
                />
              </div>
              <button className="p-2 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors">
                <Filter className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="card p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-accent-1/20 rounded-lg">
                    <Icon className="w-5 h-5 text-accent-1" />
                  </div>
                  <span className="text-sm text-green-400 font-medium">{stat.change}</span>
                </div>
                <div className="text-2xl font-bold mb-1">{stat.value}</div>
                <div className="text-sm text-white/60">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? 'bg-accent-1/20 text-accent-1 border border-accent-1/30'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.name}
              </button>
            );
          })}
        </div>

        {/* Content */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Graphique linéaire */}
            <div className="card p-6">
              <h3 className="text-lg font-semibold mb-4">Évolution des métriques</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={lineSeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="name" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px'
                    }} 
                  />
                  <Line type="monotone" dataKey="projets" stroke="#22d3ee" strokeWidth={2} />
                  <Line type="monotone" dataKey="participants" stroke="#a78bfa" strokeWidth={2} />
                  <Line type="monotone" dataKey="messages" stroke="#fbbf24" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Topics */}
            <div className="card p-6">
              <h3 className="text-lg font-semibold mb-4">Top Topics</h3>
              <div className="space-y-3">
                {topics.map((topic) => (
                  <div key={topic.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: topic.color }}
                      />
                      <span className="text-white/80">{topic.name}</span>
                    </div>
                    <span className="text-accent-1 font-medium">{topic.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'network' && (
          <div className="card p-6">
            <h3 className="text-lg font-semibold mb-4">Réseau de connexions</h3>
            <div className="h-96 border border-white/10 rounded-lg overflow-hidden">
              <ForceGraph2D
                graphData={networkData}
                nodeLabel="name"
                nodeColor="color"
                nodeVal="size"
                linkColor={() => '#374151'}
                linkWidth={2}
                backgroundColor="#0b1020"
                width={800}
                height={400}
              />
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Ranking */}
            <div className="card p-6">
              <h3 className="text-lg font-semibold mb-4">Classement des participants</h3>
              <div className="space-y-3">
                {ranking.map((user) => (
                  <div key={user.rank} className="flex items-center gap-4 p-3 bg-white/5 rounded-lg">
                    <div className="w-8 h-8 bg-accent-1/20 rounded-full flex items-center justify-center text-sm font-medium">
                      {user.avatar}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">{user.name}</div>
                      <div className="text-sm text-white/60">{user.projects} projets</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-accent-1">{user.score}</div>
                      <div className="text-sm text-white/60">pts</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bar Chart */}
            <div className="card p-6">
              <h3 className="text-lg font-semibold mb-4">Activité par mois</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={lineSeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="name" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px'
                    }} 
                  />
                  <Bar dataKey="projets" fill="#22d3ee" />
                  <Bar dataKey="participants" fill="#a78bfa" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default HandshakeDashboardTemplate;
