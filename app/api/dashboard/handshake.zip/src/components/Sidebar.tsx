import React from 'react';

const tabs = ['Vue d\'ensemble', 'New Project', 'Table Ronde IA', 'Suivi'];

const Sidebar: React.FC = () => {
  return (
    <nav className="card p-3 w-56 h-full">
      <ul className="space-y-2">
        {tabs.map(t => (
          <li key={t} className="px-3 py-2 hover:bg-white/5 rounded-lg cursor-pointer">{t}</li>
        ))}
      </ul>
    </nav>
  );
};

export default Sidebar;
