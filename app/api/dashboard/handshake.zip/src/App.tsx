import React from 'react';
import HandshakeDashboardTemplate from './components/HandshakeDashboardTemplate';

function App() {
  return <HandshakeDashboardTemplate />;
}

export default App;
